#pragma once

#include "gl/glew.h"

extern GLuint hexVao, hexVbo;

void Initbuffer();

