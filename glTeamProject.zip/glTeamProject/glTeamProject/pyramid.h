#pragma once

#include "gl/glew.h"

extern GLuint pyramidVao, pyramidVbo;

void InitPyramidBuffer();