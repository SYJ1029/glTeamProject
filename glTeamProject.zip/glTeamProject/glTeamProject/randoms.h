#pragma once
#include <stdlib.h>
#include <time.h>

float GetRandomNumber(int seed);